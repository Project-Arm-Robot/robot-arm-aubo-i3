# URDF to DH Parameterization

v0.0.1

Sometimes people want DH... ```¯\_(ツ)_/¯```

## Documentation

Check out the [documentation](https://mcevoyandy.github.io/urdf_to_dh/index.html) for more details on how the conversion is done and how to use this package.

## Running the node

```
ros2 run urdf_to_dh generate_dh --ros-args -p urdf_file:="<path_to_my_urdf>"
```
